To create the edeployPOS installer follow the steps:

INSTALLATION
 - Execute generate_installer.bat file and wait until it finishes
 - The files "edeployPOSInstaller - linux.zip" and "edeployPOSInstaller - windows.zip" will be generated. These zips contain all necessary files to install
 - Verify if the zips were created and there is an "edeployPOSInstaller.exe" file inside install windows zip and an "edeployPOS.x86_64.rpm" inside linux zip
 - After all changes in the install process it is necessary to recreate "edeployPOS.x86_64.rpm" file