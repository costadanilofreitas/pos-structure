from util import Util

Util(installing_apache=True).configure_apache_conf()
