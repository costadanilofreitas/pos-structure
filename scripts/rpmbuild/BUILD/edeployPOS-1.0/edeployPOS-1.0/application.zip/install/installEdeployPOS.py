from util import Util

Util().install()
