To create the executable (installEdeployPOS.exe) follow the steps:

PRE INSTALLATION
 - pyinstaller must be installed
 - to install run the command -> pip install pyinstaller=3.5

INSTALLATION
 - Open CMD on scripts\install
 - Run the command -> pyinstaller -F installEdeployPOS.py
 - The executable will be generate on scripts\install\dist
 - Join the requirements.txt to installEdeployPOS.exe. It is mandatory to installation