from util import Util

Util().update()
