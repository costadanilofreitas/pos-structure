def migrate(conn, tables):
    updateTablesPriority = ['StockoutItems']

    for table in updateTablesPriority:
        if len(tables[table]['fields_Common']) == 0:
            continue
        strCommonFields = ', '.join(tables[table]['fields_Common'])
        stmt = 'INSERT OR REPLACE INTO {0} ({1}) SELECT {1} FROM old.{0};'.format(table, strCommonFields)
        conn.query(stmt)
