def migrate(conn, tables):
    updateTablesPriority = ["Employee", "TimePunch", "TimePunchAdjustments", "EmployeeCustomData"]
    stmt = """
        DELETE FROM BOLaborDBParameters;
        INSERT INTO BOLaborDBParameters(TriggersEnabled) VALUES(0);
    """
    conn.query(stmt)

    for table in updateTablesPriority:
        if tables[table]["fields_OldDB"]:
            strCommonFields = ", ".join(tables[table]["fields_Common"])
            stmt = "INSERT OR REPLACE INTO %s (%s) SELECT %s FROM old.%s;" % (table, strCommonFields, strCommonFields, table)
            conn.query(stmt)

    stmt = """
        DELETE FROM BOLaborDBParameters;
        INSERT INTO BOLaborDBParameters(TriggersEnabled) VALUES(1);
    """
    conn.query(stmt)
