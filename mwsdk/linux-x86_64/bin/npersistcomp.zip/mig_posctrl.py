def migrate(conn, tables):
    updateTablesPriority = ["PosState", "PosHistory", "UserCount", "CustomModel"]

    for table in updateTablesPriority:
        strCommonFields = ", ".join(tables[table]["fields_Common"])
        stmt = "INSERT OR REPLACE INTO %s (%s) SELECT %s FROM old.%s;" % (table, strCommonFields, strCommonFields, table)
        conn.query(stmt)
