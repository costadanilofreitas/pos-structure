def migrate(conn, tables):
    updateTablesPriority = ["ProductionOrders", "PersistentStatus", "EventLog", "OrderStatistics"]

    for table in updateTablesPriority:
        if len(tables[table]["fields_Common"]) == 0:
            continue
        strCommonFields = ", ".join(tables[table]["fields_Common"])
        stmt = "INSERT OR REPLACE INTO %s (%s) SELECT %s FROM old.%s;" % (table, strCommonFields, strCommonFields, table)
        conn.query(stmt)
