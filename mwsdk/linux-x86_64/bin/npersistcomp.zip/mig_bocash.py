def migrate(conn, tables):
    updateTablesPriority = [
        "StorePOSConfig", "BusinessWeek", "BusinessDate", "POSHistory",
        "POSDrawerChange", "DrawerCount", "DrawerCountDetail",
        "CashTransaction", "CashTransactionDetails"
    ]
    stmt = """
        DELETE FROM Migration;
        INSERT INTO Migration(TriggersEnabled) VALUES(0);
    """
    conn.query(stmt)

    for table in updateTablesPriority:
        if tables[table]["fields_OldDB"]:
            strCommonFields = ", ".join(tables[table]["fields_Common"])
            stmt = "INSERT OR REPLACE INTO %s (%s) SELECT %s FROM old.%s;" % (table, strCommonFields, strCommonFields, table)
            conn.query(stmt)

    stmt = """
        DELETE FROM Migration;
        INSERT INTO Migration(TriggersEnabled) VALUES(1);
    """
    conn.query(stmt)
