def migrate(conn, tables):
    updateTablesPriority = ["[Workbook]", "[WorkbookCalculation]", "[Worksheet]"]
    for table in updateTablesPriority:
        if tables[table]["fields_OldDB"]:
            strCommonFields = ", ".join(tables[table]["fields_Common"])
            stmt = "INSERT OR REPLACE INTO %s (%s) SELECT %s FROM old.%s;" % (table, strCommonFields, strCommonFields, table)
            conn.query(stmt)
