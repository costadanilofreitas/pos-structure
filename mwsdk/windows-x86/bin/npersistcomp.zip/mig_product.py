def migrate(conn, tables):
    updateTablesPriority = [
        "Product", "ProductClassification", "ProductPart",
        "PriceList", "Price", "ModifierQtyLabels",
        "Descriptions", "ProductDescriptions",
        "Dimensions", "DimensionGroups",
        "ProductKernelParams", "ProductCustomParams",
        "ProductTags", "Production", "PromoRule",
        "CurrencyExchange", "TenderType", "ProductXREF",
        "Navigation", "ProductNavigation",
    ]

    for table in updateTablesPriority:
        if tables[table]["fields_OldDB"]:
            strCommonFields = ", ".join(tables[table]["fields_Common"])
            if table != "TenderType":
                stmt = "INSERT OR REPLACE INTO %s (%s) SELECT %s FROM old.%s;" % (table, strCommonFields, strCommonFields, table)
            else:
                stmt = "INSERT OR REPLACE INTO %s (%s) SELECT %s FROM old.%s WHERE TenderId NOT IN (SELECT TenderId FROM %s);" % (table, strCommonFields, strCommonFields, table, table)
            conn.query(stmt)
