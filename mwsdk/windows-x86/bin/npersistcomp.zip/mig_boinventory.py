
def migrate(conn, tables):
    updateTablesPriority = [
        "Supplier", "StorageArea", "Department", "DepartmentSalesHistory",
        "InventoryGroup", "InventoryItem", "SupplierProduct",
        "BillOfMaterials", "InventoryCount", "InventoryControl",
        "InventoryTransaction", "Sale", "TransactionDetail",
        "OnHandsSummary", "SupplierInvoice", "InvoiceDetail"
    ]
    try:
        stmt = """
            DELETE FROM ConfigurationParameters;
            INSERT INTO ConfigurationParameters(TriggersEnabled) VALUES(0);
        """
        conn.query(stmt)
    except:
        pass

    for table in updateTablesPriority:
        if tables[table]["fields_OldDB"]:
            strCommonFields = ", ".join(tables[table]["fields_Common"])
            stmt = "INSERT OR REPLACE INTO %s (%s) SELECT %s FROM old.%s;" % (table, strCommonFields, strCommonFields, table)
            conn.query(stmt)

    try:
        stmt = """
            DELETE FROM ConfigurationParameters;
            INSERT INTO ConfigurationParameters(InventoryMethod,CostMethod,TriggersEnabled,ControlCheck) VALUES(1,1,1,0);
        """
        conn.query(stmt)
    except:
        pass
