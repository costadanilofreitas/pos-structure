def migrate(conn, tables):
    updateTablesPriority = ["[Workbook]", "[Worksheet]"]
    for table in updateTablesPriority:
        if tables[table]["fields_OldDB"]:
            strCommonFields = ", ".join(tables[table]["fields_Common"])
            stmt = """
                INSERT OR REPLACE INTO %s (%s)
                SELECT %s FROM old.%s
                WHERE [WorkbookId] IN (
                    SELECT [WorkbookId]
                    FROM old.[Workbook]
                    WHERE [ToDate] BETWEEN
                        DATE((SELECT MAX([ToDate]) FROM old.Workbook), '-30 DAYS') AND
                        (SELECT MAX([ToDate]) FROM old.Workbook)
                );
            """ % (table, strCommonFields, strCommonFields, table)
            conn.query(stmt)
